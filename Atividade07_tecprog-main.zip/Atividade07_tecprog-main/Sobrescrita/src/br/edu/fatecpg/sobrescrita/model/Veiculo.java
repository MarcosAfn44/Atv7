package br.edu.fatecpg.sobrescrita.model;

public abstract class Veiculo {
	private String marca;
	
	public void mover() {
		System.out.println("Está se movendo!");
   }

}
